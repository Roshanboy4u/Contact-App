//
//  Contact+CoreDataClass.swift
//  Contact
//
//  Created by Roshan kumar Sah on 25/06/18.
//  Copyright © 2018 Roshan kumar Sah. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Contact)
public class Contact: NSManagedObject {

}
