//
//  Country+CoreDataClass.swift
//  Contact
//
//  Created by Roshan kumar Sah on 27/06/18.
//  Copyright © 2018 Roshan kumar Sah. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Country)
public class Country: NSManagedObject {

}
