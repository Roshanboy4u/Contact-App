//
//  Country+CoreDataProperties.swift
//  Contact
//
//  Created by Roshan kumar Sah on 27/06/18.
//  Copyright © 2018 Roshan kumar Sah. All rights reserved.
//
//

import Foundation
import CoreData


extension Country {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Country> {
        return NSFetchRequest<Country>(entityName: "Country")
    }

    @NSManaged public var name: String?
    @NSManaged public var alpha2Code: String?
    @NSManaged public var callingCodes: String?

}
