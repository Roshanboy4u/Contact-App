//
//  DataModel.swift
//  Contact
//
//  Created by Roshan kumar Sah on 25/06/18.
//  Copyright © 2018 Roshan kumar Sah. All rights reserved.
//

import UIKit
import CoreData

class DataModel: NSObject {
    var managedObjectContext: NSManagedObjectContext? = nil
    var appDelegate:AppDelegate = UIApplication.shared.delegate as! AppDelegate
    static let sharedInstance = DataModel()
    
    func callAPI(url: String)  {
        let aSession = URLSession(configuration: URLSessionConfiguration.default)
        let dataTask = aSession.dataTask(with:URL(string: url)!) { (data, response, error) -> Void in
            if (error == nil) {
                if (response is HTTPURLResponse) {
                    self.parseData(data: data!)
                    
                }else {
                    //Web server is returning an error
                }

                
            }else{
                print(error?.localizedDescription as Any)
            }
            
        }
        dataTask.resume()
    }
    
    
    func parseData(data:Data) {
        
        
        
        let responseArray = try? JSONSerialization.jsonObject(with: data, options: .mutableLeaves) as! [[String : Any]]
        
        self.managedObjectContext = appDelegate.persistentContainer.viewContext
        
        /*
         * Delete previous data
         */
        
        let fetchReq:NSFetchRequest<Country> = Country.fetchRequest()
        let batchDeleteRequest = NSBatchDeleteRequest(fetchRequest: fetchReq as! NSFetchRequest<NSFetchRequestResult>)
        do {
            try managedObjectContext?.execute(batchDeleteRequest)
            
        } catch {
            // Error Handling
        }
        
        /*
         * Save Data
         */
        
        for obj in responseArray! {
            let countryObj = NSEntityDescription.insertNewObject(forEntityName: "Country", into: managedObjectContext!) as! Country
        

            if let keyUnwrapped = obj["alpha2Code"]{
                let countryCode = keyUnwrapped
                countryObj.alpha2Code = countryCode as? String
                print(countryCode)
            }
            
            if let keyUnwrapped = obj["name"]{
                let countryName = keyUnwrapped
                countryObj.name = countryName as? String
                print(countryName)
            }
            
            if let keyUnwrapped = obj["callingCodes"]{
                let callingCodes = keyUnwrapped as! Array<Any>
                print(callingCodes)
                if callingCodes.count>0{
                    countryObj.callingCodes = callingCodes[0] as? String
                }else{
                    countryObj.callingCodes = ""
                }

            }
           
        }
        appDelegate.saveContext()
        
    }
    
    
    func fetchArray() -> [Any]? {
        
        let managedObjContex = appDelegate.persistentContainer.viewContext
        
        let fetchReq:NSFetchRequest<Country> = Country.fetchRequest()
        
        let attributeEmpty = ""
        let predicate = NSPredicate(format: "((name != %@) OR (alpha2Code != %@) OR (callingCodes != %@))", attributeEmpty, attributeEmpty, attributeEmpty)
        
        let sortDesc = NSSortDescriptor(key: "name", ascending: true)
        
        
        fetchReq.predicate = predicate
        fetchReq.sortDescriptors = [sortDesc]
        
        
        let fetchedData = try?managedObjContex.fetch(fetchReq)
        print(fetchedData!)
        return fetchedData
        
        
    }
    
    
}





