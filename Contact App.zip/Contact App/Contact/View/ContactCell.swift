//
//  ContactCell.swift
//  Contact
//
//  Created by Roshan kumar Sah on 25/06/18.
//  Copyright © 2018 Roshan kumar Sah. All rights reserved.
//

import UIKit

class ContactCell: UITableViewCell {

    @IBOutlet weak var imgContact: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        imgContact.layer.cornerRadius = 30
        imgContact.layer.masksToBounds = true;
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func updateEachCell(name:String, imgData: Data){
//        self.imgContact =
        self.lblName.text = name
        
    }
    
    func configureCell(contact: Contact){
        //        self.imgContact =
        self.lblName.text = contact.name! 
        self.imgContact.image = #imageLiteral(resourceName: "download")
        
    }
    
}


