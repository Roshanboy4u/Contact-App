//
//  ImageTableViewCell.swift
//  Contact
//
//  Created by Roshan kumar Sah on 26/06/18.
//  Copyright © 2018 Roshan kumar Sah. All rights reserved.
//

import UIKit

class ImageTableViewCell: UITableViewCell {

    @IBOutlet weak var imgViewContact: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        imgViewContact.layer.cornerRadius = 100
        imgViewContact.layer.masksToBounds = true;
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
