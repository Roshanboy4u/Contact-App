//
//  ViewController.swift
//  Contact
//
//  Created by Roshan kumar Sah on 25/06/18.
//  Copyright © 2018 Roshan kumar Sah. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UITableViewController, NSFetchedResultsControllerDelegate {

    var managedObjectContext: NSManagedObjectContext? = nil
    var searchController = UISearchController(searchResultsController: nil)
    @IBOutlet weak var aTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        /*
         * Delegate and data source conformed
         */
        self.aTableView.delegate = self
        self.aTableView.dataSource = self
        
        
        /*
         * Cell Registration
         */
        self.aTableView.register(UINib(nibName: "ContactCell", bundle: nil), forCellReuseIdentifier: "ContactCell")
       
        /*
         * Configure edit and add button
         */
        navigationItem.leftBarButtonItem = editButtonItem
        
        let addButton = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addContact(_:)))
        navigationItem.rightBarButtonItem = addButton
        
        /*
         * Instance of Appdelegate
         */
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        managedObjectContext = appDelegate.persistentContainer.viewContext
        
        /*
         * Configure SearchViewController
         */
        configureViewController()
    
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @objc
    func addContact(_ sender: Any) {
        let detailVC = self.storyboard?.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
        detailVC.delegate = self
        self.navigationController?.pushViewController(detailVC, animated: true)
        
    }

    var fetchedResultsController: NSFetchedResultsController<Contact> {
        if _fetchedResultsController != nil {
            return _fetchedResultsController!
        }

        let fetchRequest: NSFetchRequest<Contact> = Contact.fetchRequest()

        // Set the batch size to a suitable number.
        fetchRequest.fetchBatchSize = 20

        // Edit the sort key as appropriate.
        let sortDescriptor = NSSortDescriptor(key: "name", ascending: false)

        fetchRequest.sortDescriptors = [sortDescriptor]

        // Edit the section name key path and cache name if appropriate.
        // nil for section name key path means "no sections".
        let aFetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: self.managedObjectContext!, sectionNameKeyPath: nil, cacheName: nil)
        aFetchedResultsController.delegate = self
        _fetchedResultsController = aFetchedResultsController

        do {
            try _fetchedResultsController!.performFetch()
        } catch {
            // Replace this implementation with code to handle the error appropriately.
            // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
            let nserror = error as NSError
            fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
        }

        return _fetchedResultsController!
    }
    var _fetchedResultsController: NSFetchedResultsController<Contact>? = nil
    
    
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        aTableView.beginUpdates()
    }

    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
        switch type {
        case .insert:
            aTableView.insertRows(at: [newIndexPath!], with: .fade)
        case .delete:
            aTableView.deleteRows(at: [indexPath!], with: .fade)
        case .move:
            break
        case .update:
            configureCell(aTableView.cellForRow(at: indexPath!)! as! ContactCell, withContact: anObject as! Contact)
            
        }
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange sectionInfo: NSFetchedResultsSectionInfo, atSectionIndex sectionIndex: Int, for type: NSFetchedResultsChangeType) {
        switch type {
        case .insert:
            tableView.insertSections(IndexSet(integer: sectionIndex), with: .fade)
        case .delete:
            tableView.deleteSections(IndexSet(integer: sectionIndex), with: .fade)
        default:
            return
        }
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let context = fetchedResultsController.managedObjectContext
            context.delete(fetchedResultsController.object(at: indexPath))
            
            do {
                try context.save()
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nserror = error as NSError
                print("Unresolved error \(nserror), \(nserror.userInfo)")
                
            }
        }
    }
    

    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        aTableView.endUpdates()
    }
    
    /*
     // Implementing the above methods to update the table view in response to individual changes may have performance implications if a large number of changes are made simultaneously. If this proves to be an issue, you can instead just implement controllerDidChangeContent: which notifies the delegate that all section and object changes have been processed.
     
     func controllerDidChangeContent(controller: NSFetchedResultsController) {
     // In the simplest, most efficient, case, reload the table view.
     tableView.reloadData()
     }
     */


}

// MARK: Extension for TableView Delegate and DataSource

extension ViewController {
    
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return fetchedResultsController.sections?.count ?? 0
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let sectionInfo = fetchedResultsController.sections![section]
        return sectionInfo.numberOfObjects
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = aTableView.dequeueReusableCell(withIdentifier: "ContactCell", for: indexPath) as! ContactCell
        let eachContact = fetchedResultsController.object(at: indexPath)
        configureCell(cell, withContact: eachContact)
        
        return cell
    }
    
    func configureCell(_ cell: ContactCell, withContact eachContact: Contact) {
       cell.configureCell(contact: eachContact)
    }
    
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let detailVC = self.storyboard?.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
        detailVC.delegate = self
        let tappedContact = fetchedResultsController.object(at: indexPath)
        detailVC.selectedContact = tappedContact
        self.navigationController?.pushViewController(detailVC, animated: true)
        
    }
    
   
    
}

// MARK: Protocols
extension ViewController: ConfirmMeForContactDetails {
    func saveOrUpdateContact(contactDetail: Dictionary<String, String>?, contact: Contact?) {
        
        if contact == nil {
            let context = self.fetchedResultsController.managedObjectContext
            let newContact = Contact(context: context)
            newContact.name = contactDetail?["fname"]
            newContact.lname = contactDetail?["lname"]
            newContact.email = contactDetail?["email"]
            newContact.phone = contactDetail?["phone"]
            newContact.country = contactDetail?["country"]
            do {
                try context.save()
            } catch  {
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
            
        }else{
            contact?.name = contactDetail?["fname"]
            contact?.lname = contactDetail?["lname"]
            contact?.email = contactDetail?["email"]
            contact?.phone = contactDetail?["phone"]
            contact?.country = contactDetail?["country"]
            
        }
    }
}

// MARK: Extension UISearchViewController

extension ViewController : UISearchResultsUpdating {
    
    func updateSearchResults(for searchController: UISearchController) {
        let searchText = searchController.searchBar.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        
        var predicate:NSPredicate?
        if searchText?.count != 0 {
            predicate = NSPredicate(format: "name CONTAINS[cd] %@", searchText!)
            fetchedResultsController.fetchRequest.predicate = predicate!
        }else{
    
            fetchedResultsController.fetchRequest.predicate = nil
        }
        
        do {
            try _fetchedResultsController!.performFetch()
        } catch {
            let nserror = error as NSError
            print("Unresolved error \(nserror), \(nserror.userInfo)")
        }
        aTableView.reloadData()
        
    }
    
    func configureViewController() {
        
        searchController.searchResultsUpdater = self
        searchController.dimsBackgroundDuringPresentation = false
        
        self.aTableView.tableHeaderView = searchController.searchBar
        self.definesPresentationContext = true
        
    }
    
    
    
    
    
}
