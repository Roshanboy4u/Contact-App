//
//  DetailViewController.swift
//  Contact
//
//  Created by Roshan kumar Sah on 25/06/18.
//  Copyright © 2018 Roshan kumar Sah. All rights reserved.
//

import UIKit

/*
 * Protocol
 */
protocol ConfirmMeForContactDetails {
//   func saveContactToCoreData(fname:String, lname:String, email:String, country:String, phone:String)
    func saveOrUpdateContact(contactDetail : Dictionary<String,String>?, contact:Contact?)
    
}


class DetailViewController: UIViewController {

    @IBOutlet weak var addToContact: UIButton!
    var delegate : ConfirmMeForContactDetails?
    var selectedContact : Contact?
    var countryCode:String? = nil
    
    var labl = UILabel()
    
    
  
    @IBOutlet weak var aTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /*
         * Delegate and data source conformed
         */
        self.aTableView.delegate = self
        self.aTableView.dataSource = self

        /*
         * Cell Registration
         */
        self.aTableView.register(UINib(nibName: "ImageTableViewCell", bundle: nil), forCellReuseIdentifier: "ImageTableViewCell")
        self.aTableView.register(UINib(nibName: "InputTableViewCell", bundle: nil), forCellReuseIdentifier: "InputTableViewCell")
        
        
        if selectedContact != nil {
            addToContact.setTitle("Update Contact", for: .normal)
        }
        let tap = UITapGestureRecognizer(target: self, action: #selector(keyboardDismiss))
        aTableView.addGestureRecognizer(tap)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func showAlert(message:String)  {
        let alertController = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default) { (action) in
            
        }
        alertController.addAction(OKAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    @objc func keyboardDismiss(sender:UITapGestureRecognizer){
        self.view.endEditing(true)
        aTableView.contentOffset = CGPoint(x: 0.0, y: 0)
    }
    
    @objc func tapFunction(sender:UITapGestureRecognizer) {
        let countryListVC = self.storyboard?.instantiateViewController(withIdentifier: "CountryListTableViewController") as! CountryListTableViewController
        countryListVC.delegate = self
        self.navigationController?.pushViewController(countryListVC, animated: true)
    }
    
    @IBAction func addContact(_ sender: Any) {
        let cell = aTableView.cellForRow(at: IndexPath.init(row: 1, section: 0)) as! InputTableViewCell
        
        let validFirstName =  validateText(str: cell.txtFirstName.text!)
        let lastName  =  validateText(str: cell.txtLastName.text!)
        if !validFirstName && !lastName {
            showAlert(message: "Name is required")
            return
        }
        
        let validEmailId    =  validEmail(str : cell.txtEmail.text!)
        
        if !validEmailId {
            showAlert(message: "Valid Email ID is required")
            return
        }
//        let validPhone     =  validatePhone(str: cell.txtPhone.text!)
        if (cell.txtPhone.text?.count)! < 6 {
            showAlert(message: "Valid Phone No. is required")
            return
        }
         var countryDic = [String:String]()
        if(selectedContact != nil){
//            selectedContact?.name = cell.txtFirstName.text
//            selectedContact?.lname = cell.txtLastName.text!
//            selectedContact?.email = cell.txtEmail.text!
//            selectedContact?.phone = cell.txtPhone.text!
//            selectedContact?.country = cell.lblCountryCode.text!
           
            countryDic = ["fname":cell.txtFirstName.text!, "lname":cell.txtLastName.text!,"email": cell.txtEmail.text!,"country":cell.lblCountryCode.text!,"phone": cell.txtPhone.text!]
            delegate?.saveOrUpdateContact(contactDetail: countryDic, contact: selectedContact)
        }else{
            countryDic = ["fname":cell.txtFirstName.text!, "lname":cell.txtLastName.text!,"email": cell.txtEmail.text!,"country":cell.lblCountryCode.text!,"phone": cell.txtPhone.text!]
            delegate?.saveOrUpdateContact(contactDetail: countryDic, contact: nil)
//            delegate?.saveContactToCoreData(fname: cell.txtFirstName.text!, lname: cell.txtLastName.text!, email: cell.txtEmail.text!, country: cell.lblCountryCode.text!, phone: cell.txtPhone.text!)
        }
         self.navigationController?.popViewController(animated: true)
        
    }
    
}


extension DetailViewController: UITableViewDataSource, UITableViewDelegate {
    
     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.row == 0 {
            let cell = aTableView.dequeueReusableCell(withIdentifier: "ImageTableViewCell", for: indexPath) as! ImageTableViewCell
            cell.imgViewContact.image = #imageLiteral(resourceName: "download")
            return cell
        }else {
            
            let cell = aTableView.dequeueReusableCell(withIdentifier: "InputTableViewCell", for: indexPath) as! InputTableViewCell
            
            cell.txtFirstName.text = selectedContact?.name
            cell.txtFirstName.delegate = self
            cell.txtLastName.text = selectedContact?.lname
            cell.txtLastName.delegate = self
            cell.txtEmail.text = selectedContact?.email
            cell.txtEmail.delegate = self
            cell.txtPhone.text = selectedContact?.phone
            cell.txtPhone.delegate = self
//            cell.lblCountryCode.text = countryCode ?? (selectedContact?.country ?? "IN")
//            let lbl = UILabel (cell.contentView .viewWithTag(1222))
            labl = cell.contentView.viewWithTag(1222) as! UILabel
            
            

            let tap = UITapGestureRecognizer(target: self, action: #selector(tapFunction))
            cell.lblCountryCode.addGestureRecognizer(tap)
            return cell
        }

    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if indexPath.row == 0{
            return 250
        }else {
           return 217
        }
    }
}

extension DetailViewController: UITextFieldDelegate{
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        let nextTag = textField.tag + 1
        
        let nextResponder = textField.superview?.viewWithTag(nextTag) as UIResponder?
        
        if nextResponder != nil {
            nextResponder?.becomeFirstResponder()
        } else {
            textField.resignFirstResponder()
        }
        
        return false
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        aTableView.contentOffset = CGPoint(x: 0.0, y: 100.0)
       
    }
    
    
}


extension DetailViewController: ConfirmMeForCountryDetails {
    
    func fetchCountyCode(alpha2Code: String) {
        countryCode = alpha2Code
        labl.text = alpha2Code
    }
    
    
    
}


